<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RmDonation extends Model
{
    protected $table = 'rmsm_donation';
    use HasFactory;
}
