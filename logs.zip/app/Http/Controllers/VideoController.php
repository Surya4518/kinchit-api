<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class VideoController extends Controller
{
    public function storeVideoTime(Request $request)
    {
       
        $videoRecord = DB::table('videowatchingrecord')->where('user_id', $request->user_id)
            ->where('video_name', $request->video_name)
            ->first();

        if (!$videoRecord) {
            // Insert a new record
            $videoRecord = DB::table('videowatchingrecord')->insert([
                'user_id' =>$request->user_id,
                'video_name' => $request->video_name,
                'start_time' => now(),
                'total_time_watched' => $request->totalTimeWatched,
            ]);
        } else {
            // Update the existing record
            $videoRecord->total_time_watched = $request->totalTimeWatched;
            $videoRecord->save();
        }

        return response()->json(['message' => 'Data stored successfully']);
    }
}
