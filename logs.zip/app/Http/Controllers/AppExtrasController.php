<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Exception;
use Illuminate\Support\Facades\Session;
use App\Mail\MyMail;
use Illuminate\Support\Facades\Mail;

class AppExtrasController extends Controller
{
    public function GalleryCategories(Request $request){
        try{
        $gallery_cat = DB::table('gallery_category')
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->orderBy('sort_order','ASC')
        ->get();
        $arr = [];
        if($gallery_cat->isNotEmpty()){
            for($i = 0; $i < $gallery_cat->count(); $i++){
                $gallery_image = DB::table('gallery_images')
                ->where('category_id','=',$gallery_cat[$i]->id)
                ->get();
                $arr[] = [
                    'id' => $gallery_cat[$i]->id,
                    'category' => $gallery_cat[$i]->category_name,
                    'thumbimage' => $gallery_image[0]->image,
                    'description' => $gallery_image[0]->description
                    ];
            }
        }
        return response()->json(count($arr) ? ['status' => 200, 'data' => $arr] : ['status' => 400, 'message' => 'No Data..!']);
        }catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'error' => $e->getMessage(),
            ]);
        }
    }
    
    public function GalleryCategoryImages(Request $request){
        try{
        $gallery_cat = DB::table('gallery_category')
        ->where('id','=',$request->cat_id)
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->get();
        $gallery_images = DB::table('gallery_images')
        ->where('category_id','=',$request->cat_id)
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->orderBy('sort_order','ASC')
        ->get();
        return response()->json($gallery_images->isNotEmpty() ? ['status' => 200, 'Category Data' => $gallery_cat, 'data' => $gallery_images] : ['status' => 400, 'message' => 'No Data..!']);
        }catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'error' => $e->getMessage(),
            ]);
        }
    }
    
    // public function KinchitSanchika(Request $request){
    //     try{
    //     $sanchika_tamil = DB::table('kinchit_sanchika')
    //     ->where('status', '=', 'Active')
    //     ->where('language', 'like', 'Tamil')
    //     ->whereNull('deleted_at')
    //     ->orderBy('sort_order','ASC')
    //     ->get();
    //     $sanchika_english = DB::table('kinchit_sanchika')
    //     ->where('status', '=', 'Active')
    //     ->where('language', 'like', 'English')
    //     ->whereNull('deleted_at')
    //     ->orderBy('sort_order','ASC')
    //     ->get();
    //     return response()->json($sanchika_tamil->isNotEmpty() || $sanchika_english->isNotEmpty() ? ['status' => 200, 'data' => ['Tamil' => $sanchika_tamil, 'English' => $sanchika_english]] : ['status' => 400, 'message' => 'No Data..!']);
    //     }catch (Exception $e) {
    //         return response()->json([
    //             'status' => 500,
    //             'error' => $e->getMessage(),
    //         ]);
    //     }
    // }

    public function KinchitSanchikaCategory(Request $request){
    try{
        $sanchikas = DB::table('kinchit_sanchika')
            ->where('status', '=', 'Active')
            ->whereNull('deleted_at')
            ->orderBy('sort_order','ASC')
            ->get();

        $arr = [];

        if($sanchikas->isNotEmpty()){
            foreach($sanchikas as $sanchika){
                $language = DB::table('language')
                    ->where('id', '=', $sanchika->language)
                    ->first();

                if($language){
                    $arr[] = [
                        'id' => $sanchika->id,
                        'category' => $sanchika->title,
                        'lang' => [
                            'id' => $language->id,
                            'language' => $language->name,
                        ],
                    ];
                }
            }
        }

        return response()->json(count($arr) ? ['status' => 200, 'data' => $arr] : ['status' => 400, 'message' => 'No Data..!']);
    } catch (Exception $e) {
        return response()->json([
            'status' => 500,
            'error' => $e->getMessage(),
        ]);
    }
}

    public function KinchitSanchika(Request $request){
        try{
        $language = DB::table('language')
        ->where('id','=',$request->languageid)
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->get();
        $sanchika = DB::table('kinchit_sanchika')
        ->where('language','=',$request->languageid)
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->orderBy('sort_order','ASC')
        ->get();
        return response()->json($sanchika->isNotEmpty() ? ['status' => 200, 'Language Data' => $language, 'data' => $sanchika] : ['status' => 400, 'message' => 'No Data..!']);
        }catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'error' => $e->getMessage(),
            ]);
        }
    }
    
    
    public function SpecialCategories(Request $request){
        try{
        $special_cat = DB::table('special_pro_category')
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->orderBy('sort_order','ASC')
        ->get();
        return response()->json($special_cat->isNotEmpty() ? ['status' => 200, 'data' => $special_cat] : ['status' => 400, 'message' => 'No Data..!']);
        }catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'error' => $e->getMessage(),
            ]);
        }
    }
    
    public function SpecialCategoryContents(Request $request){
        try{
        $special_cat = DB::table('special_pro_category')
        ->where('id','=',$request->cat_id)
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->get();
        $special_contents = DB::table('special_pro_contents')
        ->where('category_id','=',$request->cat_id)
        ->where('status', '=', 'Active')
        ->whereNull('deleted_at')
        ->orderBy('sort_order','ASC')
        ->get();
        return response()->json($special_contents->isNotEmpty() ? ['status' => 200, 'Category Data' => $special_cat, 'data' => $special_contents] : ['status' => 400, 'message' => 'No Data..!']);
        }catch (Exception $e) {
            return response()->json([
                'status' => 500,
                'error' => $e->getMessage(),
            ]);
        }
    }
    
    public function notifyPush(Request $request){
        $userId = $request->user_id;
        $message = $request->message;
        $title = $request->title;

        $result = $this->SendPushNotification($userId, $message, $title);

        if ($result) {
            // Notification sent successfully
            return response()->json(['success' => true]);
        } else {
            // Failed to send notification
            return response()->json(['success' => false]);
        }
    }
    
    function SendPushNotification($userId = NULL, $message = NULL, $title = NULL){
        
        $fcmUrl = 'https://fcm.googleapis.com/fcm/send';
        
        $fcmToken = \Illuminate\Support\Facades\DB::table('wpu6_users')
            ->where('ID', '=', $userId)
            ->value('fcm_token');
    
        if (!$fcmToken) {
            return false;
        }
    
        $notification = [
            'title' => $title ?: 'Test',
            'body' => $message
        ];
    
        $extraData = [
            'message' => $notification,
            'moredata' => 'Nothing'
        ];
    
        $fcmNotification = [
            'to' => $fcmToken,
            'notification' => $notification,
            'data' => $extraData
        ];
    
        $headers = [
            'Authorization: key=' . env('FIREBASE_API_KEY'),
            'Content-Type: application/json'
        ];
    
        $ch = curl_init();
    
        curl_setopt($ch, CURLOPT_URL, $fcmUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
    
        $result = json_decode(curl_exec($ch));
        $error = curl_error($ch); // Check for cURL errors
        curl_close($ch);
    
        if ($error) {
            return false;
        }
    
        return isset($result->success) ? $result->success : false;
    }
    
}
