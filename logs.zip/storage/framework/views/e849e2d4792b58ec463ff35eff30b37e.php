<!DOCTYPE html>
<html>

<head>
    <title>My Email</title>
</head>

<body>
    <?php if(isset($data['name'])): ?>
    <h1>Dear <?php echo e($data['name']); ?>,</h1>
    <p style="font-size: large;">We received a request to reset the password for your Kinchitkaram account. To proceed with the password reset,</p>
    <p style="font-size: large;">please click on the link below: <br> <b style="color: blue;">Click here: http://kinchit-front.senthil.in.net/changepassword/<?php echo e($data['token']); ?></b></p>
    <p style="font-size: large;">If you did not request a password reset, please ignore this email, and your account will remain secure.</p>
    <p style="font-size: large;">Thank you for using Kinchitkaram.</p>
    <p style="font-size: large;">Best regards,</p>
    <p style="font-size: large;">Kinchitkaram Trust</p>
    <?php elseif(isset($arr['otp'])): ?>
    <h1>Dear <?php echo e($arr['display_name']); ?>,</h1>
    <p style="font-size: large;">Welcome to Kinchitkaram Trust!</p>
    <p style="font-size: large;">Here is your One-Time Password to register your account and join us.</p>
    <p style="font-size: large;">OTP: <b style="color: blue;"><?php echo e($arr['otp']); ?></b></p>
    <p style="font-size: large;">Thank you for choosing Kinchitkaram.</p>
    <p style="font-size: large;">Best regards,</p>
    <p style="font-size: large;">Kinchitkaram Trust, Old No 6,</p>
    <p style="font-size: large;">Bheemasena Garden Street, </p>
    <p style="font-size: large;">Mylapore, Chennai – 600 004, </p>
    <p style="font-size: large;">Tamil Nadu, India</p>
    <p style="font-size: large;">Phone: 044 - 24992728</p>
    <?php elseif(isset($member) && isset($member['display_name']) && isset($password)): ?>
    <h1>Dear <?php echo e($member['display_name']); ?>,</h1>
    <p style="font-size: large;">User Name: <b><?php echo e($member['display_name']); ?></b></p>
    <p style="font-size: large;">Password: <b><?php echo e($password); ?></b></p>
    <?php elseif(isset($contactus['name'])): ?>
    <h1>Dear <?php echo e($contactus['name']); ?>,</h1>
    <p style="font-size: large;">Name: <b><?php echo e($contactus['name']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($contactus['email']); ?></b></p>
    <p style="font-size: large;">Message: <b><?php echo e($contactus['message']); ?></b></p>
    <?php elseif(isset($conformail['FromID'])): ?>
    <p style="font-size: large;">From Id: <b><?php echo e($conformail['FromID']); ?></b></p>
    <p style="font-size: large;">To Id: <b><?php echo e($conformail['ToId']); ?></b></p>
    <p style="font-size: large;">Message: <b><?php echo e($conformail['Msg']); ?></b></p>
    <?php elseif(isset($gnanakaithaa['name_of_student'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($gnanakaithaa['name_of_student']); ?></b></p>
    <p style="font-size: large;">contact No: <b><?php echo e($gnanakaithaa['contact_no']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($gnanakaithaa['email']); ?></b></p>
    <?php elseif(isset($assigncourse['name_of_student'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($assigncourse['name_of_student']); ?></b></p>
    <p style="font-size: large;">contact No: <b><?php echo e($assigncourse['phone_number']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($assigncourse['email']); ?></b></p>
    <?php elseif(isset($matri['Name'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($matri['Name']); ?></b></p>
    <p style="font-size: large;">contact No: <b><?php echo e($matri['Mobile']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($matri['ConfirmEmail']); ?></b></p>
    <?php elseif(isset($userdetails['user_login'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($userdetails['user_login']); ?></b></p>
    <p style="font-size: large;"> <b>Your Approval Request is Successfully</b></p>
    <?php elseif(isset($addmember['Name'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($addmember['first_name']); ?><?php echo e($addmember['last_name']); ?></b></p>
    <p style="font-size: large;">contact No: <b><?php echo e($addmember['phone_number']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($addmember['user_email']); ?></b></p>
    <?php elseif(isset($depositdetails['first_name'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($depositdetails['first_name']); ?><?php echo e($depositdetails['last_name']); ?></b></p>
    <p style="font-size: large;">contact No: <b><?php echo e($depositdetails['phone_number']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($depositdetails['user_email']); ?></b></p>
    <?php elseif(isset($changevoluteer['first_name'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($changevoluteer['first_name']); ?><?php echo e($changevoluteer['last_name']); ?></b></p>
    <p style="font-size: large;">contact No: <b><?php echo e($changevoluteer['phone_number']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($changevoluteer['user_email']); ?></b></p>
    <?php elseif(isset($paymentoption['first_name'])): ?>
    <p style="font-size: large;">User Name: <b><?php echo e($paymentoption['first_name']); ?><?php echo e($paymentoption['last_name']); ?></b></p>
    <p style="font-size: large;">contact No: <b><?php echo e($paymentoption['phone_number']); ?></b></p>
    <p style="font-size: large;">Email: <b><?php echo e($paymentoption['user_email']); ?></b></p>
    <?php else: ?>
    <h1>Dear <?php echo e($updatepassword['display_name']); ?>,</h1>
    <p style="font-size: large;">User Name: <b><?php echo e($updatepassword['display_name']); ?></b></p>
    <p style="font-size: large;">Password: <b><?php echo e($updatepassword['password']); ?></b></p>
    <?php endif; ?>
</body>

</html><?php /**PATH /home1/senthilin/kinchitapi.senthil.in.net/resources/views/emails/my_mail.blade.php ENDPATH**/ ?>