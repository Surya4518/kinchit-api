<!DOCTYPE html>
<html>
<head>
    <title>My Email</title>
</head>
<body>
    <h1>Dear <?php echo e($data['name']); ?>,</h1>
    <p style="font-size: large;">We received a request to reset the password for your Kinchitkaram account. To proceed with the password reset,</p>
    <p style="font-size: large;">please click on the link below: <br> <b style="color:blue;"><?php echo e($data['token']); ?></b></p>
    <p style="font-size: large;">If you did not request a password reset, please ignore this email, and your account will remain secure.</p>
    <p style="font-size: large;">Thank you for using Kinchitkaram.</p>
    <p style="font-size: large;">Best regards,</p>
    <p style="font-size: large;">Kinchitkaram Trust</p>
</body>
</html><?php /**PATH C:\wamp64\www\kinchitapi.senthil.in.net\kinchitapi.senthil.in.net\resources\views/emails/my_mail.blade.php ENDPATH**/ ?>